# CLAUDE.md — Master Prompt do Projeto Vida & Carteira

> Este arquivo é a fonte única de verdade do projeto. Toda sessão do Claude Code
> nesta pasta começa lendo este arquivo. Não modifique sem antes consultar Eduardo.

## Identidade do projeto

**Nome:** Vida & Carteira
**Proprietário:** Eduardo Campos
**Propósito:** Sistema pessoal privado que organiza a trajetória de vida do proprietário em seis dimensões, do nascimento (1986) até cinco anos à frente (2031), com revisão trimestral guiada. Funciona como diário reflexivo para o passado e painel de gestão para o futuro.

**Tagline interna:** *"Da infância ao norte de cinco anos — uma vida vista como carteira."*

---

## Os seis pilares (hierarquia explícita)

A hierarquia abaixo é **parâmetro do sistema**, não decoração. Aparece em ordem visual, sensibilidade de alertas e peso na revisão trimestral.

1. **Saúde** (prioridade 1) — cor vermelho — corpo, mente, hábitos
2. **Família** (prioridade 2) — cor coral — marido, mãe, pai, irmãos, sobrinhos
3. **Trabalho** (prioridade 3) — cor âmbar — Onix Capital, carreira, propósito profissional
4. **Relacionamentos** — cor roxo — amizades, sócios não-Onix, mentores
5. **Material** — cor verde água — patrimônio, posses, evolução de net worth
6. **Espiritual** — cor azul — valores, crenças, autoconhecimento

---

## Princípios não-negociáveis

Os princípios abaixo guiam toda decisão de implementação. Em caso de conflito entre eles, a ordem listada vale.

1. **Privacidade total.** O sistema não tem URL pública navegável. Dados criptografados em repouso com AES-GCM. Chave nunca sai do navegador.
2. **Marco com reflexão.** Marco histórico sem campo `reflection` preenchido é incompleto. UI deve cobrar reflexão na criação e na transição prospectivo→histórico.
3. **JSON antes de UI.** Nenhuma feature visual é construída sem que o schema correspondente esteja definido e validado.
4. **Hierarquia respeitada.** Saúde, Família e Trabalho aparecem primeiro em qualquer listagem ordenada por dimensão.
5. **Densidade variável.** Anos vazios são informação válida. UI não deve preencher artificialmente nem esconder lacunas.
6. **Constelação, não régua.** A linha do tempo é decorativa; o que importa é a presença dos marcos. Não exibir tempo decorrido entre marcos como métrica.

---

## Arquitetura técnica

**Stack:**
- Frontend estático: HTML + CSS + JavaScript vanilla (sem framework por ora)
- Persistência: arquivo `data/marcos.json.enc` (criptografado AES-GCM)
- Hospedagem: GitHub Pages em **repositório privado** (chamar `vida-e-carteira`)
- Visualização da constelação: SVG nativo com zoom programático
- Bibliotecas externas mínimas — só o necessário, importadas via CDN com SRI

**Estrutura de pastas:**
```
vida-e-carteira/
├── CLAUDE.md                    (este arquivo)
├── index.html                   (entrada, com gate de senha)
├── assets/
│   ├── app.js                   (lógica principal)
│   ├── crypto.js                (AES-GCM, derivação de chave)
│   ├── constellation.js         (renderização SVG)
│   ├── review.js                (fluxo de revisão trimestral)
│   └── styles.css
├── data/
│   ├── marcos.json.enc          (criptografado, versionado)
│   ├── pessoas.json.enc         (criptografado, versionado)
│   └── schema/
│       ├── marco.schema.json    (referência do schema)
│       └── pessoa.schema.json
├── docs/
│   ├── ARCHITECTURE.md
│   ├── PRIVACY.md
│   └── REVIEW-RITUAL.md
└── .agents/                     (definições dos sub-agentes)
    ├── schema-keeper.md
    ├── privacy-guardian.md
    ├── constellation-builder.md
    └── review-conductor.md
```

---

## Schema dos dados

### Marco histórico (passado vivido)

```json
{
  "id": "string-kebab-case-com-ano",
  "type": "historico",
  "title": "string curto",
  "year": 2023,
  "month": 8,
  "dimension": "saude | familia | relacionamentos | trabalho | material | espiritual",
  "weight": 1-10,
  "description": "string livre",
  "reflection": {
    "learning": "string — o que aprendi com isso",
    "belief_reinforced": "string — qual crença este marco reforçou"
  },
  "tags": ["array", "de", "strings"],
  "people": ["ids-de-pessoas"],
  "created_at": "YYYY-MM-DD"
}
```

### Marco prospectivo (presente e futuro)

```json
{
  "id": "string-kebab-case-com-ano",
  "type": "prospectivo",
  "title": "string curto",
  "year": 2026,
  "month": 7,
  "dimension": "saude | familia | relacionamentos | trabalho | material | espiritual",
  "weight": 1-10,
  "description": "string livre",
  "target": {
    "deadline": "YYYY-MM-DD",
    "indicators": [
      { "metric": "string", "status": "aberta | parcial | feito", "pct": 0-100 }
    ]
  },
  "decisions": [
    {
      "id": "string",
      "topic": "string",
      "options": [
        { "label": "string", "score": 1-10 }
      ],
      "chosen": null | "label",
      "deadline": "YYYY-MM-DD"
    }
  ],
  "tags": ["array"],
  "people": ["ids"],
  "created_at": "YYYY-MM-DD"
}
```

### Pessoa

```json
{
  "id": "kebab-case",
  "name": "Nome completo ou apelido",
  "relation": "marido | mae | pai | irmao | irma | socio | mentor | amigo | outro",
  "since": "YYYY-MM",
  "dimension": "familia | relacionamentos | trabalho",
  "notes": "string opcional"
}
```

---

## O time de sub-agentes

Este projeto usa **quatro sub-agentes especialistas**, cada um com seu contexto, prompts e ferramentas. O Claude Code (maestro) delega tarefas a eles em paralelo quando apropriado.

### Sub-agente 1 — Schema Keeper

**Arquivo de definição:** `.agents/schema-keeper.md`
**Responsabilidade:** Garantir que `marco.schema.json` e `pessoa.schema.json` estão atualizados, válidos (JSON Schema draft 2020-12) e que toda operação de leitura/escrita os respeita. Implementa funções de validação em `app.js`.
**Não toca em:** UI, criptografia, ritual de revisão.
**Worktree sugerido:** `schema/`

### Sub-agente 2 — Privacy Guardian

**Arquivo de definição:** `.agents/privacy-guardian.md`
**Responsabilidade:** Implementar gate de senha, derivação de chave (PBKDF2 com 100k iterações no mínimo), criptografia AES-GCM do `marcos.json.enc`, e backup local automático em IndexedDB. Documentar processo de recuperação em `docs/PRIVACY.md`.
**Não toca em:** schema dos dados, visualização, ritual.
**Worktree sugerido:** `privacy/`

### Sub-agente 3 — Constellation Builder

**Arquivo de definição:** `.agents/constellation-builder.md`
**Responsabilidade:** Renderizar a constelação SVG (1986–2031) com zoom em três níveis (vida inteira / década / ano), filtros por dimensão, painel lateral de detalhe ao clicar em marco. Cores da paleta dos pilares.
**Não toca em:** criptografia, ritual, schema (apenas consome o schema validado pelo Schema Keeper).
**Worktree sugerido:** `constellation/`

### Sub-agente 4 — Review Conductor

**Arquivo de definição:** `.agents/review-conductor.md`
**Responsabilidade:** Implementar o fluxo guiado de Revisão Trimestral em seis blocos (Saúde, Família, Trabalho, Relacionamentos, Material, Espiritual), com perguntas estruturadas e gravação das respostas como marcos novos ou updates.
**Não toca em:** visualização da constelação, criptografia (consome funções já prontas).
**Worktree sugerido:** `review/`

---

## Como o maestro orquestra

O Claude Code, ao receber uma instrução do Eduardo via prompt, deve:

1. **Ler este arquivo (`CLAUDE.md`) primeiro.** Sempre.
2. **Identificar qual(is) sub-agente(s) é(são) necessário(s)** para a tarefa.
3. **Se for um sub-agente apenas:** delegar diretamente.
4. **Se forem dois ou mais:** criar worktrees separados e rodar em paralelo, com merge final no `main`.
5. **Validar saída:** antes de commit, validar que o trabalho não fere nenhum dos seis princípios não-negociáveis.
6. **Atualizar este arquivo** se algum princípio, schema ou estrutura mudou (com aprovação de Eduardo).

### Regras de paralelização

- Schema Keeper sempre roda primeiro se a tarefa envolve mudança de dado.
- Privacy Guardian e Constellation Builder podem rodar em paralelo (não compartilham arquivos).
- Review Conductor depende de Schema Keeper estar terminado.
- Nunca rodar dois agentes editando o mesmo arquivo ao mesmo tempo.

---

## Roadmap em fases (referência para o maestro)

**Fase 1 — Fundação (semanas 1 a 3)**
- Schema Keeper define schemas.
- Privacy Guardian implementa gate de senha + criptografia.
- Constellation Builder renderiza versão estática com 5 marcos de exemplo.
- Eduardo cadastra 20 marcos reais.

**Fase 2 — Profundidade do passado (semanas 4 a 8)**
- Constellation Builder adiciona zoom e filtros.
- Schema Keeper adiciona entidade Pessoas.
- Eduardo cadastra 60 a 100 marcos cobrindo a vida inteira.

**Fase 3 — Painel do futuro (semanas 9 a 14)**
- Review Conductor implementa fluxo trimestral.
- Schema Keeper adiciona suporte a marcos prospectivos completos.
- Constellation Builder adiciona renderização tracejada para prospectivos.

**Fase 4 — Integração e legado (semanas 15 a 20)**
- Decidir destino do `/viagens` público.
- Métricas vivas no dashboard.
- Documentação final.

---

## Ferramentas auxiliares fora do Claude Code

**Claude Design:** Eduardo usa para prototipar visualmente a constelação, telas de detalhe de marco e fluxo de revisão **antes** do Constellation Builder implementar. Outputs do Claude Design viram referências em `docs/design/`.

**Claude in Chrome:** Eduardo usa para testar a UI rodando no navegador depois de cada deploy local. Verifica gate de senha, fluxos de criação de marco, renderização da constelação em mobile e desktop.

**Claude Chat (cérebro):** Eduardo usa para decisões estratégicas, redação de novos prompts para o Claude Code, validação de propostas e reflexão sobre os marcos a cadastrar.

---

## Convenções de código

- **Idioma:** Comentários e variáveis em português. Strings de UI sempre em português brasileiro.
- **Estilo:** JavaScript moderno (ES2022+), sem transpilador. Tudo deve rodar nativamente em navegadores modernos.
- **Sem npm install:** dependências via CDN (cdnjs, esm.sh, unpkg) com SRI obrigatório.
- **Sem framework:** sem React, sem Vue, sem Svelte. Vanilla JS com módulos.
- **Acessibilidade:** ARIA labels, contraste WCAG AA mínimo, navegação por teclado.
- **Mobile-first:** o sistema é usado tanto no celular quanto no desktop.

---

## Checkpoints visuais obrigatórios

Antes de fechar qualquer feature visual, o Constellation Builder deve gerar **um screenshot** (ou descrição visual detalhada) e Eduardo deve aprovar via Claude Chat antes do merge.

**Lista de checkpoints da Fase 1:**
- [ ] Gate de senha — tela de entrada
- [ ] Constelação com 5 marcos de exemplo
- [ ] Painel lateral de detalhe de marco
- [ ] Filtro por dimensão funcionando
- [ ] Backup local no IndexedDB confirmado

---

## Como Eduardo dá instruções ao Claude Code

Padrão recomendado:

```
> [DIMENSÃO DA TAREFA] [VERBO] [OBJETO] [RESTRIÇÃO OPCIONAL]
```

Exemplos válidos:
```
> SCHEMA adicionar campo "private" booleano ao marco histórico
> PRIVACY implementar fluxo de mudança de senha sem perda de dados
> CONSTELLATION ajustar zoom para suportar deslize por touch no mobile
> REVIEW criar variação do ritual para revisão anual (não só trimestral)
```

O Claude Code, ao receber, identifica a dimensão, delega ao sub-agente correto, e reporta de volta com proposta de implementação antes de executar.

---

## Critério de "pronto"

Uma feature está pronta quando:

1. Passa nos testes manuais previstos para ela.
2. Não fere nenhum dos seis princípios não-negociáveis.
3. Tem screenshot ou demonstração aprovada por Eduardo.
4. Está documentada em `docs/` se for arquitetural.
5. O backup local foi testado após a mudança.

---

## Palavra final ao maestro

Este sistema é privado, pessoal e tem peso emocional. Não é um app de mercado. Decisões devem priorizar **clareza, privacidade e respeito ao significado** acima de elegância técnica ou padrões de indústria. Quando estiver em dúvida, escolha o caminho mais simples, mais seguro e mais respeitoso ao usuário (que é o próprio Eduardo).
