#!/usr/bin/env bash
# ============================================================================
# Vida & Carteira - Bootstrap Linux Autonomo (Etapa 2 de 2)
# ============================================================================
# Este script faz TUDO o resto sozinho dentro do Ubuntu:
#   - Atualiza o sistema
#   - Instala Node.js v20 LTS
#   - Instala/configura Git
#   - Instala Claude Code
#   - Valida tudo
#   - Gera relatorio final
#
# COMO USAR:
#   No terminal Ubuntu, cole este comando unico e pressione Enter:
#
#   curl -fsSL https://raw.githubusercontent.com/edurcampos86-jpg/vida-e-carteira-setup/main/bootstrap.sh | bash
#
#   (Se voce ainda nao subiu o script no GitHub, alternativa:
#   salve este arquivo como bootstrap.sh, de permissao com
#   chmod +x bootstrap.sh, e execute com ./bootstrap.sh)
#
# TEMPO ESTIMADO: 10 a 20 minutos (a maior parte automatica).
# ACAO MANUAL: somente autenticacao OAuth do Claude Code no fim.
# ============================================================================

set -e
trap 'handle_error $? $LINENO' ERR

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
GRAY='\033[0;90m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Variaveis de estado
ERRORS=0
WARNINGS=0
START_TIME=$(date +%s)
LOG_FILE="$HOME/vida-carteira-bootstrap.log"

# ============================================================================
# Funcoes auxiliares
# ============================================================================

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') | $1" >> "$LOG_FILE"
}

print_header() {
    echo ""
    echo -e "${CYAN}============================================================${NC}"
    echo -e "${CYAN}${BOLD}  $1${NC}"
    echo -e "${CYAN}============================================================${NC}"
}

print_step() {
    echo ""
    echo -e "${BLUE}==>${NC} ${BOLD}$1${NC}"
    log "STEP: $1"
}

print_ok() {
    echo -e "    ${GREEN}[OK]${NC} $1"
    log "OK: $1"
}

print_warn() {
    echo -e "    ${YELLOW}[!]${NC}  $1"
    WARNINGS=$((WARNINGS + 1))
    log "WARN: $1"
}

print_fail() {
    echo -e "    ${RED}[X]${NC}  $1"
    ERRORS=$((ERRORS + 1))
    log "FAIL: $1"
}

print_info() {
    echo -e "    ${GRAY}$1${NC}"
}

handle_error() {
    local exit_code=$1
    local line=$2
    echo ""
    echo -e "${RED}============================================================${NC}"
    echo -e "${RED}${BOLD}  ERRO INESPERADO${NC}"
    echo -e "${RED}============================================================${NC}"
    echo -e "Codigo de saida: ${exit_code}"
    echo -e "Linha: ${line}"
    echo ""
    echo -e "${YELLOW}Acao: copie esta mensagem completa e cole no Claude Chat.${NC}"
    echo -e "${YELLOW}Log completo: ${LOG_FILE}${NC}"
    exit "$exit_code"
}

# ============================================================================
# Inicio
# ============================================================================

clear
print_header "Vida & Carteira - Bootstrap Linux"
echo -e "${GRAY}  Etapa 2 de 2 - Instalacao automatica no Ubuntu${NC}"
echo -e "${GRAY}  Log completo em: ${LOG_FILE}${NC}"
echo ""

log "==== BOOTSTRAP STARTED ===="
log "User: $(whoami)"
log "Distro: $(lsb_release -ds 2>/dev/null || echo 'unknown')"

# ============================================================================
# Verificacao 1: ambiente WSL
# ============================================================================
print_step "Verificando ambiente"

if grep -qi microsoft /proc/version 2>/dev/null; then
    print_ok "Rodando dentro do WSL"
else
    print_warn "Nao detectei WSL - pode estar em Linux nativo"
fi

if [ "$(id -u)" -eq 0 ]; then
    print_fail "Voce esta como root. Saia (digite 'exit') e rode como usuario normal."
    exit 1
fi
print_ok "Usuario nao-root: $(whoami)"

# Testar sudo (vai pedir senha)
echo ""
echo -e "${YELLOW}    Vou precisar da sua senha do Linux uma vez para o sudo.${NC}"
echo -e "${GRAY}    A senha nao aparece enquanto voce digita (e normal).${NC}"
echo ""
if sudo -v; then
    print_ok "Sudo autenticado"
else
    print_fail "Falha ao autenticar sudo. Verifique sua senha."
    exit 1
fi

# Manter sudo vivo durante o script
( while true; do sudo -n true; sleep 50; kill -0 "$$" || exit; done 2>/dev/null ) &
SUDO_KEEPER_PID=$!
trap "kill $SUDO_KEEPER_PID 2>/dev/null; exit" INT TERM EXIT

# ============================================================================
# Etapa 1: atualizar o sistema
# ============================================================================
print_step "Atualizando indice de pacotes (apt update)"
sudo apt update -qq > /dev/null 2>&1
print_ok "Indice atualizado"

print_step "Atualizando pacotes existentes (pode demorar 3-5 min)"
print_info "Apenas pacotes com seguranca pendente serao atualizados..."
sudo DEBIAN_FRONTEND=noninteractive apt upgrade -y -qq > /dev/null 2>&1
print_ok "Sistema atualizado"

# Pacotes auxiliares
print_step "Instalando ferramentas basicas (curl, ca-certificates)"
sudo apt install -y -qq curl ca-certificates gnupg > /dev/null 2>&1
print_ok "Ferramentas basicas prontas"

# ============================================================================
# Etapa 2: Node.js v20
# ============================================================================
print_step "Verificando Node.js"

INSTALL_NODE=false
if command -v node > /dev/null 2>&1; then
    CURRENT_NODE=$(node --version | sed 's/v//' | cut -d. -f1)
    if [ "$CURRENT_NODE" -ge 20 ]; then
        print_ok "Node.js $(node --version) ja instalado (suficiente)"
    else
        print_warn "Node.js $(node --version) detectado - precisa ser v20+"
        INSTALL_NODE=true
    fi
else
    print_info "Node.js nao encontrado"
    INSTALL_NODE=true
fi

if [ "$INSTALL_NODE" = true ]; then
    print_step "Instalando Node.js v20 LTS via NodeSource"
    print_info "Adicionando repositorio oficial..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - > /dev/null 2>&1
    print_info "Baixando e instalando (pode demorar 2-3 min)..."
    sudo apt install -y -qq nodejs > /dev/null 2>&1
    print_ok "Node.js $(node --version) instalado"
fi

print_ok "npm $(npm --version) disponivel"

# ============================================================================
# Etapa 3: Git
# ============================================================================
print_step "Verificando Git"

if ! command -v git > /dev/null 2>&1; then
    print_info "Git nao encontrado - instalando..."
    sudo apt install -y -qq git > /dev/null 2>&1
fi
print_ok "Git $(git --version | awk '{print $3}') disponivel"

# Configurar Git se ainda nao foi
print_step "Verificando configuracao do Git"
GIT_NAME=$(git config --global user.name 2>/dev/null || echo "")
GIT_EMAIL=$(git config --global user.email 2>/dev/null || echo "")

if [ -z "$GIT_NAME" ] || [ -z "$GIT_EMAIL" ]; then
    echo ""
    echo -e "${YELLOW}    Git precisa do seu nome e email para identificar commits.${NC}"
    echo -e "${GRAY}    Use o mesmo email da sua conta GitHub.${NC}"
    echo ""

    if [ -z "$GIT_NAME" ]; then
        read -rp "    Seu nome completo (ex: Eduardo Campos): " input_name
        git config --global user.name "$input_name"
        print_ok "Nome configurado: $input_name"
    fi

    if [ -z "$GIT_EMAIL" ]; then
        read -rp "    Seu email do GitHub: " input_email
        git config --global user.email "$input_email"
        print_ok "Email configurado: $input_email"
    fi
else
    print_ok "Nome: $GIT_NAME"
    print_ok "Email: $GIT_EMAIL"
fi

# Helper de credenciais (para PAT)
git config --global credential.helper store
print_ok "Credential helper ativado (PAT sera lembrado apos primeiro uso)"

# ============================================================================
# Etapa 4: Claude Code
# ============================================================================
print_step "Verificando Claude Code"

INSTALL_CLAUDE=false
if command -v claude > /dev/null 2>&1; then
    print_ok "Claude Code ja instalado: $(claude --version 2>/dev/null || echo 'versao desconhecida')"
    print_info "Atualizando para ultima versao..."
    sudo npm install -g @anthropic-ai/claude-code > /dev/null 2>&1
    print_ok "Claude Code atualizado: $(claude --version 2>/dev/null)"
else
    print_info "Claude Code nao encontrado - instalando..."
    print_info "Aguarde 1 a 3 minutos..."
    sudo npm install -g @anthropic-ai/claude-code > /dev/null 2>&1
    if command -v claude > /dev/null 2>&1; then
        print_ok "Claude Code instalado: $(claude --version 2>/dev/null)"
    else
        print_fail "Instalacao do Claude Code falhou."
        print_info "Tentando alternativa sem sudo (npm global do usuario)..."
        mkdir -p ~/.npm-global
        npm config set prefix '~/.npm-global'
        echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.bashrc
        export PATH=~/.npm-global/bin:$PATH
        npm install -g @anthropic-ai/claude-code
        if command -v claude > /dev/null 2>&1; then
            print_ok "Claude Code instalado (modo usuario): $(claude --version 2>/dev/null)"
        else
            print_fail "Instalacao falhou em ambas as tentativas."
            print_info "Cole o conteudo do log no Claude Chat: $LOG_FILE"
            exit 1
        fi
    fi
fi

# ============================================================================
# Etapa 5: Relatorio final
# ============================================================================
END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))
MINUTES=$((ELAPSED / 60))
SECONDS=$((ELAPSED % 60))

print_header "RELATORIO FINAL"

echo ""
echo -e "  ${BOLD}Tempo total:${NC} ${MINUTES}m ${SECONDS}s"
echo -e "  ${BOLD}Erros:${NC} $ERRORS"
echo -e "  ${BOLD}Avisos:${NC} $WARNINGS"
echo ""
echo -e "  ${BOLD}Versoes instaladas:${NC}"
echo -e "    Node.js:     $(node --version 2>/dev/null || echo 'nao instalado')"
echo -e "    npm:         $(npm --version 2>/dev/null || echo 'nao instalado')"
echo -e "    Git:         $(git --version 2>/dev/null | awk '{print $3}' || echo 'nao instalado')"
echo -e "    Claude Code: $(claude --version 2>/dev/null || echo 'nao instalado')"
echo ""

if [ "$ERRORS" -eq 0 ]; then
    echo -e "${GREEN}============================================================${NC}"
    echo -e "${GREEN}${BOLD}  SETUP CONCLUIDO COM SUCESSO${NC}"
    echo -e "${GREEN}============================================================${NC}"
    echo ""
    echo -e "${CYAN}${BOLD}PROXIMA ACAO MANUAL UNICA (~2 min):${NC}"
    echo ""
    echo -e "  1. Autenticar Claude Code. Cole no terminal:"
    echo ""
    echo -e "     ${YELLOW}claude${NC}"
    echo ""
    echo -e "  2. Ele vai mostrar uma URL. Copie e cole no navegador."
    echo -e "  3. Faca login com sua conta Claude. Autorize."
    echo -e "  4. Volte ao terminal. Saia com ${YELLOW}Ctrl+C${NC}."
    echo ""
    echo -e "${CYAN}${BOLD}DEPOIS DISSO:${NC}"
    echo ""
    echo -e "  Volte ao Claude Chat e diga: ${BOLD}'Passo 1 concluido'${NC}"
    echo -e "  Voce recebera o Passo 2 (criacao do repositorio)."
    echo ""
else
    echo -e "${RED}============================================================${NC}"
    echo -e "${RED}${BOLD}  SETUP COM ERROS - ATENCAO NECESSARIA${NC}"
    echo -e "${RED}============================================================${NC}"
    echo ""
    echo -e "${YELLOW}Acao: cole o conteudo do log no Claude Chat para diagnostico:${NC}"
    echo ""
    echo -e "  ${BOLD}cat $LOG_FILE${NC}"
    echo ""
fi

log "==== BOOTSTRAP FINISHED ===="
log "Errors: $ERRORS | Warnings: $WARNINGS | Duration: ${MINUTES}m${SECONDS}s"

# Liberar trap (script terminou bem)
trap - INT TERM EXIT
kill $SUDO_KEEPER_PID 2>/dev/null || true

exit "$ERRORS"
