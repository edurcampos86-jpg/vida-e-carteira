# ============================================================================
# Vida & Carteira - Bootstrap Inicial (Etapa 1 de 2)
# ============================================================================
# Este script habilita WSL2 e instala Ubuntu no Windows.
#
# COMO USAR:
#   1. Salvar este arquivo como bootstrap-wsl.ps1 na sua área de trabalho.
#   2. Botão direito no PowerShell -> "Executar como administrador".
#   3. Cole o comando abaixo no PowerShell e pressione Enter:
#
#      Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force; & "$HOME\Desktop\bootstrap-wsl.ps1"
#
# TEMPO ESTIMADO: 5 a 15 minutos (depende da sua internet).
# AÇÃO MANUAL APÓS: reiniciar o computador.
# ============================================================================

$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message, [string]$Color = "Cyan")
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor $Color
}

function Write-Success { param([string]$Message) Write-Host "    [OK] $Message" -ForegroundColor Green }
function Write-Warn    { param([string]$Message) Write-Host "    [!]  $Message" -ForegroundColor Yellow }
function Write-Fail    { param([string]$Message) Write-Host "    [X]  $Message" -ForegroundColor Red }

Clear-Host
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  Vida & Carteira - Bootstrap WSL2 + Ubuntu" -ForegroundColor Cyan
Write-Host "  Etapa 1 de 2 - Preparacao do ambiente Windows" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# Verificar privilegios de administrador
Write-Step "Verificando privilegios de administrador"
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
if (-not $isAdmin) {
    Write-Fail "Este script precisa rodar como administrador."
    Write-Host ""
    Write-Host "Solucao: Feche este PowerShell. Abra novamente clicando" -ForegroundColor Yellow
    Write-Host "com o botao direito no PowerShell e escolha" -ForegroundColor Yellow
    Write-Host "'Executar como administrador'." -ForegroundColor Yellow
    Read-Host "`nPressione Enter para sair"
    exit 1
}
Write-Success "Rodando como administrador"

# Verificar versao do Windows
Write-Step "Verificando versao do Windows"
$winVersion = [System.Environment]::OSVersion.Version
$buildNumber = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").CurrentBuild
Write-Success "Windows build $buildNumber detectado"

if ([int]$buildNumber -lt 19041) {
    Write-Fail "Sua versao do Windows e antiga demais para WSL2 (precisa build 19041 ou superior)."
    Write-Host "Atualize o Windows pelo Windows Update antes de continuar." -ForegroundColor Yellow
    Read-Host "`nPressione Enter para sair"
    exit 1
}

# Verificar se WSL ja esta instalado
Write-Step "Verificando estado atual do WSL"
$wslInstalled = $false
$ubuntuInstalled = $false

try {
    $wslOutput = wsl --status 2>&1
    if ($LASTEXITCODE -eq 0) {
        $wslInstalled = $true
        Write-Success "WSL ja esta instalado"

        # Verificar se Ubuntu existe
        $distros = wsl --list --quiet 2>&1 | Where-Object { $_ -match "Ubuntu" }
        if ($distros) {
            $ubuntuInstalled = $true
            Write-Success "Ubuntu ja esta instalado"
        }
    }
} catch {
    Write-Warn "WSL ainda nao esta configurado"
}

# Decidir acao
if ($wslInstalled -and $ubuntuInstalled) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host "  Bom! WSL e Ubuntu ja estao instalados." -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Proximo passo:" -ForegroundColor Cyan
    Write-Host "  1. Abra o app 'Ubuntu' pelo menu Iniciar." -ForegroundColor White
    Write-Host "  2. Se for primeira abertura: crie usuario e senha Linux." -ForegroundColor White
    Write-Host "  3. Volte ao Claude Chat e diga: 'Ubuntu aberto'" -ForegroundColor White
    Write-Host "     para receber o Script 2 (bootstrap dentro do Linux)." -ForegroundColor White
    Write-Host ""
    Read-Host "Pressione Enter para fechar"
    exit 0
}

# Instalar WSL + Ubuntu
Write-Step "Instalando WSL2 + Ubuntu (pode demorar 5 a 15 minutos)" "Yellow"
Write-Host "    Aguarde - downloads em andamento..." -ForegroundColor Gray
Write-Host ""

try {
    wsl --install -d Ubuntu --no-launch
    if ($LASTEXITCODE -ne 0) { throw "wsl --install falhou com codigo $LASTEXITCODE" }
    Write-Success "WSL2 + Ubuntu instalados com sucesso"
} catch {
    Write-Fail "Falha na instalacao: $_"
    Write-Host ""
    Write-Host "Causas possiveis:" -ForegroundColor Yellow
    Write-Host "  - Virtualizacao nao habilitada na BIOS" -ForegroundColor Gray
    Write-Host "  - Internet instavel" -ForegroundColor Gray
    Write-Host "  - Windows precisa de atualizacoes" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Acao: copie a mensagem de erro acima e cole no Claude Chat." -ForegroundColor Cyan
    Read-Host "`nPressione Enter para sair"
    exit 1
}

# Mensagem final
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  SCRIPT 1 CONCLUIDO COM SUCESSO" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "PROXIMOS PASSOS (manuais, ~2 minutos):" -ForegroundColor Cyan
Write-Host ""
Write-Host "  1. REINICIE O COMPUTADOR agora." -ForegroundColor White -BackgroundColor DarkRed
Write-Host ""
Write-Host "  2. Apos reiniciar, abra o app 'Ubuntu' (menu Iniciar)." -ForegroundColor White
Write-Host ""
Write-Host "  3. Na primeira abertura, o Ubuntu vai pedir:" -ForegroundColor White
Write-Host "       - Username Linux (sugestao: eduardo)" -ForegroundColor Gray
Write-Host "       - Senha Linux (anote-a, sera pedida varias vezes)" -ForegroundColor Gray
Write-Host ""
Write-Host "  4. Quando o terminal Ubuntu estiver aberto," -ForegroundColor White
Write-Host "     volte ao Claude Chat e diga: 'Ubuntu aberto'." -ForegroundColor White
Write-Host "     Voce recebera o Script 2 que faz tudo o resto." -ForegroundColor White
Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""

Read-Host "Pressione Enter para fechar este PowerShell"
